module.exports = {
    s3Listener: require('./s3.listener'),
    sqsListener: require('./sqs.listener')
};